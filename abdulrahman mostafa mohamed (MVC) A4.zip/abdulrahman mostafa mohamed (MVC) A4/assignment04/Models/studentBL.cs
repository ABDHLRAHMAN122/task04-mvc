﻿using assignment02.Data.DigitalDBcontext;
using Microsoft.EntityFrameworkCore;
using assignment02.viewmodel;
namespace assignment02.Models
{
    public class studentBL
    {
        DigitalDBContexts context = new DigitalDBContexts();

        public List<student> GetAll()
        {
            return context.students
                          .Include(s => s.studept)
                          .Include(b => b.stucourse)
                          .ToList();
        }
        public student getbyid(int id)
        {
            return context.students
                          .FirstOrDefault(E => E.Id == id);
        }
        public void Add(student stud)
        {
            context.students.Add(stud);    
            context.SaveChanges();
        }
        public void SaveInDB()
        {
            context.SaveChanges();
        }
        public void Delete(student st)
        {
            context.students.Remove(st);
            context.SaveChanges();
        }

    }
}
