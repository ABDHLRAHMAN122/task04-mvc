﻿using System;
using assignment02.Data.DigitalDBcontext;
using assignment02.Models;
using assignment02.viewmodel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace assignment02.Controllers
{
    public class StudentController : Controller
    {
        studentBL stud = new studentBL();
        DepartmentBL dep = new DepartmentBL();
        public IActionResult Index()
        {
            studentBL students = new studentBL();
            List<student> stu = students.GetAll();

            return View("index", stu);
        }

        public IActionResult Details(int id)
        {
            studentBL students = new studentBL();
            student students2 = students.getbyid(id);

             return View("Details",students2);
        }
        [HttpGet]
        public IActionResult Add()
        {
            List<Department> dept = dep.ShowAll();

            studentviewmodel studentviewmodel = new studentviewmodel()
            {
                Deptlist = dept
            };

           return View("Add", studentviewmodel);
        }
        [HttpPost]
        public IActionResult SaveAdd(studentviewmodel studSent)
        {
            if (studSent.Name != null)
            {
                student newStud = new student()
                {
                    Name = studSent.Name,
                    Age = studSent.Age,
                    deptid = studSent.deptid
                };

                stud.Add(newStud); 
                stud.SaveInDB();

                return RedirectToAction(nameof(Index));
            }

            studSent.Deptlist = dep.ShowAll();
            return View("Add", studSent);
        }
        public IActionResult Edit(int id)
        {
            student stu = stud.getbyid(id);
            List<Department> dept = dep.ShowAll();

            studentviewmodel studentviewmodel = new studentviewmodel()
            {
                Id = stu.Id,
                Name = stu.Name,
                Age = stu.Age,
                deptid = stu.deptid,
                Deptlist = dept

            };
            return View("Edit", studentviewmodel);

        }
        public IActionResult SaveEdit(student studSent, int id)
        {
            if (studSent.Name != null)
            {
                student OldEmp = stud.getbyid(id);
                OldEmp.Name = studSent.Name;
                OldEmp.Id = studSent.Id;
                OldEmp.Age = studSent.Age;
                OldEmp.deptid = studSent.deptid;

                stud.SaveInDB();
                return RedirectToAction(nameof(Index));
            }
            return View("Edit", studSent);
        }
        public IActionResult Delete(int id)
        {
             return View("Delete", stud.getbyid(id));   
        }
        public IActionResult SaveDelete(int id)
        {
            student stud2 = stud.getbyid(id);
            if (stud2 != null)
            {
                stud.Delete(stud2);
                return RedirectToAction(nameof(Index));
            }
            return NotFound();
        }


    }
}
